# Glossar: Bundeswehr- und Behördensprache

55 Begriffe, die in den Ausschreibungen vorkommen und außerhalb
der Bundeswehr kaum jemand kennt. Wer eine Ausschreibung für einen Bewerber
zusammenfasst, sollte diese Wörter erklären statt sie zu übernehmen.

**ABC-Abwehr**
Schutz- und Abwehrmaßnahmen gegen nukleare, biologische und chemische Bedrohungen.

**BAIUDBw**
Bundesamt für Infrastruktur, Umweltschutz und Dienstleistungen der Bundeswehr.

**BAPersBw**
Bundesamt für das Personalmanagement der Bundeswehr, zuständig für alle Personalfragen.

**Beamtenverhältnis**
Ein öffentlich-rechtliches Dienst- und Treueverhältnis zum Staat mit besonderen Rechten und Pflichten.

**Beorderung** _(auch: Beorderungsverhältnis)_
Die feste Einplanung eines Reservisten auf einer konkreten Stelle für den Ernstfall.

**Besoldungsgruppe**
Die gesetzlich festgelegte Gehaltsstufe für Beamte und Soldaten, beispielsweise A7 oder A14.

**Bootsmann**
Ein Unteroffiziersdienstgrad der Marine, der dem Feldwebel bei Heer und Luftwaffe gleichgestellt ist.

**Dienstfahrerlaubnis** _(auch: DFE Bw)_
Der behördliche Führerschein, der zum Führen von Bundeswehr-Fahrzeugen berechtigt.

**Dienstgrad**
Der militärische Rang eines Soldaten, der Rechte, Pflichten und die Besoldung bestimmt.

**Dienstposten**
Der konkrete Arbeitsplatz oder Aufgabenbereich einer Soldatin, eines Soldaten oder Beamten.

**Eingangsamt**
Das Einstiegsamt, mit dem ein Beamter nach Beendigung des Vorbereitungsdienstes startet.

**Elektronische Kampfführung** _(auch: EloKa)_
Militärische Nutzung elektromagnetischer Wellen zur Aufklärung und Störung gegnerischer Signale.

**Entgeltgruppe**
Die Gehaltseinstufung für Tarifbeschäftigte im öffentlichen Dienst nach Aufgabengebiet.

**Feldlagerbetriebsfeldwebel**
Ein Spezialist für den technischen Betrieb der Infrastruktur in Feldlagern.

**Feldwebel**
Eigene Laufbahngruppe der Feldwebel (Unteroffiziere mit Portepee) und zugleich ihr erster Dienstgrad, mit Führungs- und Fachaufgaben. Auf dem Bewerbungsbogen ein eigenes Kästchen, getrennt von den Unteroffizieren.

**Feuerunterstützungsfeldwebel**
Ein Spezialist für die Koordinierung von Steilfeuer (Artillerie, Mörser) zur Unterstützung der Kampftruppe.

**Fregattenkapitän**
Ein hoher Dienstgrad der Marine, der der Stufe eines Oberstleutnants entspricht.

**Gehobener nichttechnischer Verwaltungsdienst**
Laufbahngruppe für gehobene Sachbearbeitungs- und Führungsaufgaben im Beamtenverhältnis.

**GeoInfoDBw** _(auch: Geoinformationsdienst der Bundeswehr)_
Geoinformationsdienst der Bundeswehr; liefert geografische und meteorologische Analysen.

**Heimatschutz** _(auch: Heimatschützer)_
Ein militärischer Bereich der Bundeswehr zur Sicherung wichtiger Infrastruktur im Inland.

**Karrierecenter**
Regionale Dienststelle für Beratung, Bewerbung und Eignungsprüfung von Bundeswehr-Interessierten.

**Kdo CIR** _(auch: Cyber/IT)_
Kommando Cyber- und Informationsraum; militärischer Bereich für Cybersicherheit und IT-Infrastruktur.

**Korvettenkapitän**
Ein hoher Dienstgrad der Marine, der der Stufe eines Majors entspricht.

**Laufbahnbefähigung**
Die rechtliche Anerkennung, dass eine Person die Ausbildungsvoraussetzungen für eine Beamtenlaufbahn erfüllt.

**Materialbewirtschaftungsfeldwebel** _(auch: Materialbewirtschaftungsfeldwebel SK)_
Feldwebel, der die Materialverwaltung, Lagerung und Bestandskontrolle leitet.

**Militärfachlicher Dienst**
Laufbahn für herausragende Unteroffiziere zur Beförderung zum Offizier.

**Militärisches Nachrichtenwesen**
Bereich zur Informationsgewinnung und Bedrohungsanalyse über potenzielle Gegner.

**Militärseelsorge** _(auch: Militärseelsorgeassistent)_
Die religiöse und seelische Betreuung von Soldatinnen und Soldaten durch Pfarrer oder Seelsorger.

**Mittlerer nichttechnischer Verwaltungsdienst**
Laufbahngruppe für allgemeine Büro- und Sachbearbeitungstätigkeiten im Beamtenverhältnis.

**Personalgewinnungszulage**
Ein finanzieller Bonus zur Gewinnung qualifizierter Fachkräfte auf dem Arbeitsmarkt.

**Pioniertruppe** _(auch: Spezialpioniere)_
Die Truppengattung, die für Bau, Sperren, Brücken und Geländegängigkeit zuständig ist.

**Reservedienst**
Dienstleistung von Reservistinnen und Reservisten in den Streitkräften nach dem Ausscheiden aus dem aktiven Dienst.

**S6 Feldwebel**
Ein Feldwebel, der in Stäben für Informationstechnik und Kommunikation zuständig ist.

**Sanitätsfeldwebel** _(auch: SanFw)_
Höherer Unteroffiziersgrad im medizinischen Dienst der Bundeswehr.

**Sanitätsoffizier**
Offizier mit medizinischem Hochschulstudium, der als Arzt, Zahnarzt, Tierarzt oder Apotheker dient.

**Sanitätsunteroffizier** _(auch: SanUffz)_
Unteroffizier des medizinischen Dienstes der Bundeswehr.

**SASPF** _(auch: SAP R/3 / SAP S/4HANA (SASPF))_
Das zentrale IT-System der Bundeswehr für Logistik, Personal und Verwaltung auf SAP-Basis.

**Sicherheitsüberprüfung** _(auch: Ü1, Ü2)_
Gesetzliche Prüfung einer Person auf Sicherheitsrisiken vor dem Zugriff auf geheime Daten.

**SLP** _(auch: Standardisiertes Sprachprofil)_
Standardisiertes Sprachprofil; ein nach NATO-Standard (STANAG 6001) genormtes Bewertungsschema für Fremdsprachenkenntnisse (Hören, Sprechen, Lesen, Schreiben, je 0-5), z.B. "SLP 3332".

**Soldat auf Zeit** _(auch: SaZ)_
Ein Soldat, der sich freiwillig für eine begrenzte Zeit zum Dienst in der Bundeswehr verpflichtet hat.

**Stabsoffizier**
Höherer militärischer Dienstgrad ab Major beziehungsweise Korvettenkapitän.

**Trennungsgeld**
Finanzielle Entschädigung bei einer dienstlich veranlassten Trennung vom Wohnort.

**Truppendienst**
Die klassische militärische Laufbahn für die Führung von Kampfeinheiten.

**Truppenküche**
Die militärische Kantine zur Verpflegung von Soldaten und zivilen Mitarbeitern.

**Truppenversorgungsbearbeiter** _(auch: Truppenversorgungsbearbeiter SK)_
Mitarbeiter, der für die Bereitstellung von Material und Verpflegung in Truppenteilen sorgt.

**TVöD**
Tarifvertrag für den öffentlichen Dienst; regelt die Arbeitsbedingungen und Bezahlung der dort Angestellten.

**Umbeorderung**
Der Wechsel eines Reservisten von einem eingeplanten Dienstposten auf einen anderen.

**Umzugskostenvergütung**
Gesetzlich geregelte Erstattung der Kosten für einen dienstlich angewiesenen Umzug.

**Unteroffizier mit Portepee**
Dienstgradgruppe der höheren Unteroffiziere ab dem Dienstgrad Feldwebel.

**Unteroffizier ohne Portepee**
Dienstgradgruppe der jüngeren Unteroffiziere in der Bundeswehr.

**UZwGBw**
Gesetz über die Anwendung unmittelbaren Zwanges durch Soldatinnen und Soldaten der Bundeswehr.

**VBL**
Versorgungsanstalt des Bundes und der Länder, welche die betriebliche Altersvorsorge im öffentlichen Dienst verwaltet.

**Verschlusssache** _(auch: VS, VS-Geheim)_
Als geheim eingestufte Information oder Unterlage der Bundeswehr oder staatlicher Behörden.

**Wehrdienstleistender**
Eine Person, die zeitweise oder im Rahmen des freiwilligen Wehrdienstes in der Bundeswehr dient.

**Zivil-militärische Zusammenarbeit** _(auch: ZMZ)_
Kooperation zwischen der Bundeswehr und zivilen Behörden bei Katastrophen oder Krisen.

## Quellen

- Erzeugt aus den Texten der Bundeswehr-Ausschreibungen selbst (Stand: laufend aktualisiert).

> Diese Übersicht ist eine Lesehilfe eines unabhängigen privaten Projekts, keine amtliche Auskunft der Bundeswehr. Verbindlich sind allein die Angaben der jeweiligen Ausschreibung, die offiziellen Seiten der Bundeswehr und die Auskunft der Karriereberatung. Regeln und Altersgrenzen ändern sich; im Zweifel dort nachfragen statt sich auf diesen Text zu verlassen.
