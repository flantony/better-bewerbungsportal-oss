# Dienstgrade und Besoldungsgruppen

## Wie die Besoldung zu lesen ist

Soldatinnen und Soldaten sowie Beamtinnen und Beamte werden nach der
**Bundesbesoldungsordnung A** bezahlt: "A 7", "A 11" und so weiter - je höher die
Zahl, desto höher die Grundbesoldung. Zivile Tarifbeschäftigte fallen dagegen
unter den Tarifvertrag mit den Entgeltgruppen **E 1 bis E 15**. In `list_jobs`
entscheidet `besoldungstabelle` ("A" oder "E"), worauf sich `mindestbesoldung`
bezieht.

Innerhalb einer Besoldungsgruppe steigt das Gehalt zusätzlich mit der
Erfahrungsstufe, und es kommen Zulagen hinzu. Die Tabelle unten sagt also, in
welcher Gruppe ein Dienstgrad liegt - nicht, was am Monatsende überwiesen wird.

## Warum hier Spannen stehen

Die Zuordnung ist im Gesetz selbst teilweise mehrdeutig: "Hauptmann" und
"Kapitänleutnant" stehen sowohl in A 11 als auch in A 12, "Oberstleutnant" und
"Fregattenkapitän" in A 14 und A 15. Welche Gruppe gilt, hängt am konkreten
Dienstposten. Deshalb wird hier immer eine Spanne genannt statt eines Wertes, der
eine Genauigkeit vortäuschen würde, die es nicht gibt.

## Sammelbezeichnungen

- **Unteroffizier mit Portepee** = die Feldwebel-Dienstgrade (A 7 aufwärts).
- **Unteroffizier ohne Portepee** = Unteroffizier und Stabsunteroffizier (A 5 bis A 6).

Wer "mit Portepee" als den Dienstgrad "Unteroffizier" liest, ordnet die Stelle
zwei Gruppen zu niedrig ein.

## Die Tabelle

### Mannschaften

| Dienstgrad | Besoldungsgruppe |
| --- | --- |
| Gefreiter | A 3 |
| Matrose | A 3 |
| Obergefreiter | A 4 |
| Hauptgefreiter | A 4 |
| Stabsgefreiter | A 5 |
| Oberstabsgefreiter | A 5 |

### Unteroffiziere

| Dienstgrad | Besoldungsgruppe |
| --- | --- |
| Unteroffizier ohne Portepee | A 5 bis A 6 |
| Unteroffiziere ohne Portepee | A 5 bis A 6 |
| Unteroffizier | A 5 |
| Maat | A 5 |
| Stabsunteroffizier | A 6 |
| Obermaat | A 6 |
| Korporal | A 6 |
| Stabskorporal | A 6 |

### Feldwebel

| Dienstgrad | Besoldungsgruppe |
| --- | --- |
| Unteroffizier mit Portepee | A 7 bis A 9 |
| Unteroffiziere mit Portepee | A 7 bis A 9 |
| Feldwebel | A 7 |
| Bootsmann | A 7 |
| Oberfeldwebel | A 7 |
| Oberbootsmann | A 7 |
| Hauptfeldwebel | A 8 |
| Hauptbootsmann | A 8 |
| Stabsfeldwebel | A 9 |
| Stabsbootsmann | A 9 |
| Oberstabsfeldwebel | A 9 |
| Oberstabsbootsmann | A 9 |

### Offiziere

| Dienstgrad | Besoldungsgruppe |
| --- | --- |
| Fahnenjunker | A 5 |
| Seekadett | A 5 |
| Fähnrich | A 7 |
| Fähnrich zur See | A 7 |
| Oberfähnrich | A 8 |
| Oberfähnrich zur See | A 8 |
| Leutnant | A 9 |
| Leutnant zur See | A 9 |
| Oberleutnant | A 10 |
| Oberleutnant zur See | A 10 |
| Seekapitän | A 10 |
| Hauptmann | A 11 bis A 12 |
| Kapitänleutnant | A 11 bis A 12 |
| Stabshauptmann | A 13 |
| Stabskapitänleutnant | A 13 |
| Major | A 13 |
| Korvettenkapitän | A 13 |
| Stabsarzt | A 13 |
| Stabsapotheker | A 13 |
| Stabsveterinär | A 13 |
| Oberstleutnant | A 14 bis A 15 |
| Fregattenkapitän | A 14 bis A 15 |
| Oberstabsarzt | A 14 |
| Oberstabsapotheker | A 14 |
| Oberstabsveterinär | A 14 |
| Oberfeldarzt | A 15 |
| Flottillenarzt | A 15 |
| Oberfeldapotheker | A 15 |
| Flottillenapotheker | A 15 |
| Oberst | A 16 |
| Kapitän zur See | A 16 |
| Oberstarzt | A 16 |
| Flottenarzt | A 16 |
| Oberstapotheker | A 16 |

## Quellen

- Bundesbesoldungsgesetz, Anlage I (Bundesbesoldungsordnungen A und B): https://www.gesetze-im-internet.de/bbesg/anlage_i.html

> Diese Übersicht ist eine Lesehilfe eines unabhängigen privaten Projekts, keine amtliche Auskunft der Bundeswehr. Verbindlich sind allein die Angaben der jeweiligen Ausschreibung, die offiziellen Seiten der Bundeswehr und die Auskunft der Karriereberatung. Regeln und Altersgrenzen ändern sich; im Zweifel dort nachfragen statt sich auf diesen Text zu verlassen.
