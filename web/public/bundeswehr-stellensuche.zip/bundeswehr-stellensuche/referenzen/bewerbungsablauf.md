# Wie eine Bewerbung bei der Bundeswehr abläuft

## Was dieses Werkzeug tut - und was nicht

Dieser Server hilft bis zum ausgefüllten Bewerbungsbogen. **Abschicken kann er
nichts.** Die Bewerbung geht immer über die offiziellen Wege der Bundeswehr, mit
der Kennung der Ausschreibung (`refCode`) als Bezug.

## Der Ablauf

1. **Ausschreibung finden und Frist prüfen.** `applicationEnd` ist der
   Bewerbungsschluss. Ist er vorbei, ist die Stelle raus - eine Bewerbung darauf
   ist verlorene Mühe.
   Wer noch nicht sicher ist, welche Laufbahn passt, spricht am besten schon
   jetzt mit der Karriereberatung der Bundeswehr - nicht erst nach dem
   Einreichen.
2. **Unterlagen zusammenstellen.** Was verlangt wird, steht in
   `get_document_requirements`: der Bewerbungsbogen selbst und die im Text
   genannten Nachweise (Lebenslauf, Zeugnisse, je nach Stelle eine Erklärung zur
   Verfassungstreue wie die "Anlage 1 zum Bewerbungsbogen", die der Bewerber
   selbst ausfüllt und unterschreibt, teils beglaubigte Übersetzungen).
3. **Bewerbungsbogen ausfüllen.** Entweder mit `fuelle_formular` oder von
   Hand auf dem Blankoformular.
4. **Bewerbung einreichen.** Im offiziellen Bewerbungsportal der Bundeswehr (https://bewerbung.bundeswehr-karriere.de) über „Karriere starten“ ein Profil anlegen, die Stelle über ihre Kennung suchen und die Unterlagen als PDF hochladen - unterschriebene Vordrucke vorher einscannen. Das Portal fragt die persönlichen Angaben dort noch einmal selbst ab. Nennt die Ausschreibung einen anderen Weg, gilt dieser.
   Die Ansprechperson steht in `contactDesc`.
5. **Karriereberatung.** Nach dem Einreichen meldet sich in der Regel die
   Karriereberatung zur Terminvereinbarung. Für militärische Laufbahnen führt der Weg über ein
   Karrierecenter der Bundeswehr. Dort wird beraten, welche Laufbahn und
   Verwendung überhaupt passt - das ist keine Formalie, sondern die Stelle, an
   der sich viele Bewerbungen noch verschieben.
6. **Eignungsfeststellung.** Mehrtägiges Verfahren im Karrierecenter: ärztliche
   Untersuchung, Sporttest, computergestützte Tests und Gespräche. Umfang und
   Dauer hängen an der angestrebten Laufbahn. Für Offiziere in der Regel
   stattdessen im Assessmentcenter für Führungskräfte der Bundeswehr in Köln.
7. **Prüfung der Verfassungstreue** - je nach Verwendung zusätzlich eine
   Sicherheitsüberprüfung. Läuft teils parallel zu den anderen Schritten.
8. **Entscheidung und Einstellungszusage.**

## Wobei die KI hier helfen kann

Erklären, Unterlagen zusammenstellen, den Bogen ausfüllen, an Fristen erinnern.
**Nicht** aber: Angaben erfinden, den Ausgang der Eignungsfeststellung
vorhersagen oder eine Zusage in Aussicht stellen.

## Quellen

- Bundeswehr Karriere, Bewerbung und Eignungsfeststellung: https://www.bundeswehrkarriere.de/
- Bundeswehr, Voraussetzungen für den Dienst: https://www.bundeswehr.de/de/menschen-karrieren/voraussetzungen-dienst
- Einreichweg und Assessmentcenter für Führungskräfte: die Ausschreibungen selbst und ihre Anlagen

> Diese Übersicht ist eine Lesehilfe eines unabhängigen privaten Projekts, keine amtliche Auskunft der Bundeswehr. Verbindlich sind allein die Angaben der jeweiligen Ausschreibung, die offiziellen Seiten der Bundeswehr und die Auskunft der Karriereberatung. Regeln und Altersgrenzen ändern sich; im Zweifel dort nachfragen statt sich auf diesen Text zu verlassen.
